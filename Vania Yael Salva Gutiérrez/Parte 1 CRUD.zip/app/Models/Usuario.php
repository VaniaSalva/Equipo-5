<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Usuario
 *
 * @property $id
 * @property $Número de empleado
 * @property $Nombre
 * @property $Primer apellido
 * @property $Segundo apellido
 * @property $Departamento/Area
 * @property $Puesto
 * @property $Estatus
 * @property $Fecha Nacimiento
 * @property $created_at
 * @property $updated_at
 *
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class Usuario extends Model
{
    
    static $rules = [
		'Número de empleado' => 'required',
		'Nombre' => 'required',
		'Primer apellido' => 'required',
		'Segundo apellido' => 'required',
		'Departamento/Area' => 'required',
		'Puesto' => 'required',
		'Estatus' => 'required',
		'Fecha Nacimiento' => 'required',
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['Número de empleado','Nombre','Primer apellido','Segundo apellido','Departamento/Area','Puesto','Estatus','Fecha Nacimiento'];



}

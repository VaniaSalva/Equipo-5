<div class="box box-info padding-1">
    <div class="box-body">

        <div class="form-group">
            {{ Form::label('Número de empleado') }}
            {{ Form::text('Número de empleado', $usuario->Número de empleado, ['class' => 'form-control' . ($errors->has('Número de empleado') ? ' is-invalid' : ''), 'placeholder' => 'Número De Empleado']) }}
            {!! $errors->first('Número de empleado', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="form-group">
            {{ Form::label('Nombre') }}
            {{ Form::text('Nombre', $usuario->Nombre, ['class' => 'form-control' . ($errors->has('Nombre') ? ' is-invalid' : ''), 'placeholder' => 'Nombre']) }}
            {!! $errors->first('Nombre', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="form-group">
            {{ Form::label('Primer apellido') }}
            {{ Form::text('Primer apellido', $usuario->Primer apellido, ['class' => 'form-control' . ($errors->has('Primer apellido') ? ' is-invalid' : ''), 'placeholder' => 'Primer Apellido']) }}
            {!! $errors->first('Primer apellido', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="form-group">
            {{ Form::label('Segundo apellido') }}
            {{ Form::text('Segundo apellido', $usuario->Segundo apellido, ['class' => 'form-control' . ($errors->has('Segundo apellido') ? ' is-invalid' : ''), 'placeholder' => 'Segundo Apellido']) }}
            {!! $errors->first('Segundo apellido', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="form-group">
            {{ Form::label('Departamento/Area') }}
            {{ Form::text('Departamento/Area', $usuario->Departamento/Area, ['class' => 'form-control' . ($errors->has('Departamento/Area') ? ' is-invalid' : ''), 'placeholder' => 'Departamento/Area']) }}
            {!! $errors->first('Departamento/Area', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="form-group">
            {{ Form::label('Puesto') }}
            {{ Form::text('Puesto', $usuario->Puesto, ['class' => 'form-control' . ($errors->has('Puesto') ? ' is-invalid' : ''), 'placeholder' => 'Puesto']) }}
            {!! $errors->first('Puesto', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="form-group">
            {{ Form::label('Estatus') }}
            {{ Form::text('Estatus', $usuario->Estatus, ['class' => 'form-control' . ($errors->has('Estatus') ? ' is-invalid' : ''), 'placeholder' => 'Estatus']) }}
            {!! $errors->first('Estatus', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="form-group">
            {{ Form::label('Fecha Nacimiento') }}
            {{ Form::text('Fecha Nacimiento', $usuario->Fecha Nacimiento, ['class' => 'form-control' . ($errors->has('Fecha Nacimiento') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Nacimiento']) }}
            {!! $errors->first('Fecha Nacimiento', '<div class="invalid-feedback">:message</div>') !!}
        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;


return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('usuarios', function (Blueprint $table) {
            $table->id();
            $table->integer("Número de empleado");
            $table->string("Nombre");
            $table->string("Primer apellido");
            $table->string("Segundo apellido");
            $table->string("Departamento/Area");
            $table->string("Puesto");
            $table->string("Estatus");
            $table->datetime("Fecha Nacimiento");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('usuarios');
    }
};

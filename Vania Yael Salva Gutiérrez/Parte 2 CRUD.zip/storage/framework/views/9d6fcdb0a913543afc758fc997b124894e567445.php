<div class="box box-info padding-1">
    <div class="box-body">

        <div class="form-group">
            <?php echo e(Form::label('Número de empleado')); ?>

            <?php echo e(Form::text('Númeroempleado', $usuario->Númeroempleado, ['class' => 'form-control' . ($errors->has('Númeroempleado') ? ' is-invalid' : ''), 'placeholder' => 'NúmeroEmpleado'])); ?>

            <?php echo $errors->first('Número de empleado', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Nombre')); ?>

            <?php echo e(Form::text('Nombre', $usuario->Nombre, ['class' => 'form-control' . ($errors->has('Nombre') ? ' is-invalid' : ''), 'placeholder' => 'Nombre'])); ?>

            <?php echo $errors->first('Nombre', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Primer apellido')); ?>

            <?php echo e(Form::text('ApellidoPaterno', $usuario->ApellidoPaterno, ['class' => 'form-control' . ($errors->has('ApellidoPaterno') ? ' is-invalid' : ''), 'placeholder' => 'ApellidoPaterno'])); ?>

            <?php echo $errors->first('ApellidoPaterno', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Segundo apellido')); ?>

            <?php echo e(Form::text('ApellidoMaterno', $usuario->ApellidoMaterno, ['class' => 'form-control' . ($errors->has('ApellidoMaterno') ? ' is-invalid' : ''), 'placeholder' => 'ApellidoMaterno'])); ?>

            <?php echo $errors->first('Segundo apellido', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Departamento/Area')); ?>

            <?php echo e(Form::text('Departamento', $usuario->Departamento, ['class' => 'form-control' . ($errors->has('Departamento') ? ' is-invalid' : ''), 'placeholder' => 'Departamento'])); ?>

            <?php echo $errors->first('Departamento/Area', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Puesto')); ?>

            <?php echo e(Form::text('Puesto', $usuario->Puesto, ['class' => 'form-control' . ($errors->has('Puesto') ? ' is-invalid' : ''), 'placeholder' => 'Puesto'])); ?>

            <?php echo $errors->first('Puesto', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Estatus')); ?>

            <?php echo e(Form::text('Estatus', $usuario->Estatus, ['class' => 'form-control' . ($errors->has('Estatus') ? ' is-invalid' : ''), 'placeholder' => 'Estatus'])); ?>

            <?php echo $errors->first('Estatus', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Fecha Nacimiento')); ?>

            <?php echo e(Form::text('Fecha Nacimiento', $usuario->FechaNacimiento, ['class' => 'form-control' . ($errors->has('FechaNacimiento') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Nacimiento'])); ?>

            <?php echo $errors->first('Fecha Nacimiento', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\CRUD\resources\views/usuario/form.blade.php ENDPATH**/ ?>

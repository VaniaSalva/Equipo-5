<?php $__env->startSection('template_title'); ?>
    <?php echo e($usuario->name ?? 'Show Usuario'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Usuario</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('usuarios.index')); ?>"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">

                        <div class="form-group">
                            <strong>Número De Empleado:</strong>
                            <?php echo e($usuario->Númeroempleado); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre:</strong>
                            <?php echo e($usuario->Nombre); ?>

                        </div>
                        <div class="form-group">
                            <strong>Primer Apellido:</strong>
                            <?php echo e($usuario->ApellidoPaterno); ?>

                        </div>
                        <div class="form-group">
                            <strong>Segundo Apellido:</strong>
                            <?php echo e($usuario->ApellidoMaterno); ?>

                        </div>
                        <div class="form-group">
                            <strong>Departamento/Area:</strong>
                            <?php echo e($usuario->Departamento); ?>

                        </div>
                        <div class="form-group">
                            <strong>Puesto:</strong>
                            <?php echo e($usuario->Puesto); ?>

                        </div>
                        <div class="form-group">
                            <strong>Estatus:</strong>
                            <?php echo e($usuario->Estatus); ?>

                        </div>
                        <div class="form-group">
                            <strong>Fecha Nacimiento:</strong>
                            <?php echo e($usuario->FechaNacimiento); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CRUD\resources\views/usuario/show.blade.php ENDPATH**/ ?>
